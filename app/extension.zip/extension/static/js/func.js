
                        var list=[];
                        var message =[];


        $(document).on('click', '#upload', function(){
        list=[];
            var numbers = document.getElementById("numbers").value;
        message = document.getElementById("message").value;
        if(numbers!=''){
        num=numbers.split(',');
        for(var i in num){
                list.push(num[i])
                }
        }

        //Reference the FileUpload element.
        var fileUpload = document.getElementById("fileUpload");
        //Validate whether File is valid Excel file.
        var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.xls|.xlsx)$/;
        if (regex.test(fileUpload.value.toLowerCase())) {
            if (typeof (FileReader) != "undefined") {
                var reader = new FileReader();

                //For Browsers other than IE.
                if (reader.readAsBinaryString) {
                    reader.onload = function (e) {
                    console.log("1");
                        GetTableFromExcel(e.target.result);
                        console.log("111");
                        otherinfo();
                    };
                    reader.readAsBinaryString(fileUpload.files[0]);
                } else {
                    //For IE Browser.
                    reader.onload = function (e) {
                        var data = "";
                        var bytes = new Uint8Array(e.target.result);
                        for (var i = 0; i < bytes.byteLength; i++) {
                            data += String.fromCharCode(bytes[i]);
                        }
                        console.log("11");
                        GetTableFromExcel(data);
                        otherinfo();

                    };
                    reader.readAsArrayBuffer(fileUpload.files[0]);
                }
            }
        }
    else{
    otherinfo();
    }
    });

    function otherinfo(){
    console.log("hello");
    console.log(list,message);
    for(var i in list){
    console.log(i);
    var win = window.open("https://wa.me/${list[i]}?text=${message}", '_blank');
    console.log('here');
//<!--    win.focus();-->
//<!--    var e = jQuery.Event('keydown');-->
//<!--    e.which = 13;-->
//<!--    $('.3FRCZ').trigger(e);-->
//<!--    }-->


    }

    function GetTableFromExcel(data) {
        //Read the Excel File data in binary
        var workbook = XLSX.read(data, {
            type: 'binary'
        });

        //get the name of First Sheet.
        var Sheet = workbook.SheetNames[0];


        //Read all rows from First Sheet into an JSON array.
        var excelRows = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[Sheet]);


        //Add the data rows from Excel file.
        for (var i = 0; i < excelRows.length; i++) {
            list.push(excelRows[i].Numbers);
            console.log(list);
        }
    };



